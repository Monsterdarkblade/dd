package me.nate.powercrystals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class RealityStone implements Listener{

	public static HashMap<UUID, Long> cooldown = new HashMap<>();
	
	private static List<Snowball> realitySnowballEntities = new ArrayList<Snowball>();
	private static List<Snowball> allStonesSnowballEntities = new ArrayList<Snowball>();
	
	public static void realityStone() {
		
		Bukkit.getScheduler().scheduleSyncRepeatingTask(InfinityStones.getPlugin(InfinityStones.class), new Runnable() {
			@Override
			public void run() {
				
				for(Player player : Bukkit.getServer().getOnlinePlayers()) {
					
					if(Config.speedAbility()) {
					if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.reality)) {
						player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 21 , (Config.speedLevel() -1)));
					}
					
				}
				
				}
			}
		}, 0L, 20L); //0 Tick initial delay, 20 Tick (1 Second) between repeats
		
		
		
		
	}
	
	@EventHandler
	public void onClick(PlayerInteractEvent e) {
			
		Player player = e.getPlayer();
		if(e.getItem() != null) {
			if(TimeStone.isGauntletItem(e.getItem())) {
	        if (e.getAction() == Action.LEFT_CLICK_AIR || e.getAction() == Action.LEFT_CLICK_BLOCK) {
	        	
	        	
	        	if(cooldown.containsKey(player.getUniqueId())) { //in cooldown
	    			if(System.currentTimeMillis() < cooldown.get(player.getUniqueId())) {
	    				return;
	    				}
	        		}
	        	
	        	
	        	if(InfinityStones.hasAllStones(player)) {
	        		if(Config.allPowerBeam()) {
	        			Projectile snowball = player.getWorld().spawn(player.getLocation().add(0,1.5,0), Snowball.class);
						snowball.setShooter(player);
			            allStonesSnowballEntities.add((Snowball) snowball);
			            snowball.setGravity(false);
			            snowball.setVelocity(player.getLocation().getDirection().normalize().multiply(2));
			            snowball.setFireTicks(40);
						player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SNOW_GOLEM_SHOOT, 1F, 1F);

		            Bukkit.getScheduler().scheduleSyncDelayedTask(InfinityStones.getPlugin(InfinityStones.class), new Runnable() {
		    			@Override
		    			public void run() {
		    				snowball.remove();
		    				if(allStonesSnowballEntities.contains(snowball))
		    					allStonesSnowballEntities.remove(snowball);
		    		}},40L);
		            
		            
		            long now = System.currentTimeMillis(); long thirtyMillis = Config.powerBeamCooldown() * 1000; long nowPlusThirty = now + thirtyMillis;
					  cooldown.put(player.getUniqueId(), nowPlusThirty);
	        		}
	        	}
	        	
	        	else if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.power)) {
					if(Config.powerBeam()) {
						Projectile snowball = player.getWorld().spawn(player.getLocation().add(0,1.5,0), Snowball.class);
						snowball.setShooter(player);
			            realitySnowballEntities.add((Snowball) snowball);
			            snowball.setGravity(false);
			            snowball.setVelocity(player.getLocation().getDirection().normalize().multiply(2));
			            snowball.setFireTicks(40);
						player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SNOW_GOLEM_SHOOT, 1F, 1F);

		            Bukkit.getScheduler().scheduleSyncDelayedTask(InfinityStones.getPlugin(InfinityStones.class), new Runnable() {
		    			@Override
		    			public void run() {
		    				if(realitySnowballEntities.contains(snowball))
		    					realitySnowballEntities.remove(snowball);
		    				snowball.remove();
		    		}},40L);
		            
		            
		            long now = System.currentTimeMillis(); long thirtyMillis = Config.powerBeamCooldown() * 1000; long nowPlusThirty = now + thirtyMillis;
					  cooldown.put(player.getUniqueId(), nowPlusThirty);
					
					
					}
	        	}

	        	
	        	
	        	}
	        }
	    			}
		
		}
	
	@EventHandler
	public void onHit(ProjectileHitEvent e) {
		
		if(e.getEntity().getType().equals(EntityType.SNOWBALL)) {
			
			try {
			
			if(realitySnowballEntities.contains(e.getEntity())) {
				realitySnowballEntities.remove(e.getEntity());

				
				for (Entity entity : e.getEntity().getWorld().getNearbyEntities(e.getEntity().getLocation(), 3, 3, 3)) {
					if(e.getEntity().getShooter() != entity) {
						
					if(entity instanceof Damageable) {
							if(!(entity instanceof ArmorStand)) {
						entity.setFireTicks((int) Config.powerStoneBeamFireTicks());
						((Damageable) entity).damage(Config.powerStoneBeamDamage());
						
							}
						}
					}
				}

				
			      e.getEntity().getWorld().spawnParticle(Particle.EXPLOSION_LARGE,e.getEntity().getLocation(),1);
			      e.getEntity().getWorld().playSound(e.getEntity().getLocation(), Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 1F, 1F);

			}	
			if(allStonesSnowballEntities.contains(e.getEntity())) {
				allStonesSnowballEntities.remove(e.getEntity());

				for (Entity entity : e.getEntity().getWorld().getNearbyEntities(e.getEntity().getLocation(), 5, 5, 5)) {
					if(e.getEntity().getShooter() != entity) {
						if(entity instanceof Damageable) {
							if(!(entity instanceof ArmorStand)) {
						entity.setFireTicks((int) Config.allStonesPowerBeamFireticks());
						((Damageable) entity).damage(Config.allStonesPowerBeamDamage());
					
							}
						}
					}
				}
			      e.getEntity().getWorld().spawnParticle(Particle.EXPLOSION_HUGE ,e.getEntity().getLocation(),1);
			      e.getEntity().getWorld().playSound(e.getEntity().getLocation(), Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 1F, 1F);

			}
			
			} catch(ClassCastException| NullPointerException x) {
				
			}
			}
		
		
		}
	public static void realityStoneRunabble() {
	Bukkit.getScheduler().scheduleSyncRepeatingTask(InfinityStones.getPlugin(InfinityStones.class), new Runnable() {
		@Override
		public void run() {
    			try {
    			
    				for(Snowball ent : realitySnowballEntities) {
    					 DustOptions dustOptions = new DustOptions(Color.fromRGB(139, 0, 209), 1);
    					 ent.getWorld().spawnParticle(Particle.REDSTONE, ent.getLocation(),10, 0.1, 0.1, 0.1, dustOptions);	
    				}
    				
    				for(Snowball ent : allStonesSnowballEntities) {
    					int i = (int)(Math.random() * 6 + 1);
    					if(i == 1) {
    						 DustOptions dustOptions = new DustOptions(Color.fromRGB(227, 0, 19), 1);
    					      ent.getWorld().spawnParticle(Particle.REDSTONE,ent.getLocation(),10, 0.1, 0.1, 0.1, dustOptions);	
    					}
    					if(i == 2) {
    						 DustOptions dustOptions = new DustOptions(Color.fromRGB(252, 140, 3), 1);
    					      ent.getWorld().spawnParticle(Particle.REDSTONE,ent.getLocation(),10, 0.1, 0.1, 0.1, dustOptions);	
    					}
    					if(i == 3) {
    						 DustOptions dustOptions = new DustOptions(Color.fromRGB(252, 227, 3), 1);
    					      ent.getWorld().spawnParticle(Particle.REDSTONE,ent.getLocation(),10, 0.1, 0.1, 0.1, dustOptions);	
    					}
    					if(i == 4) {
    						 DustOptions dustOptions = new DustOptions(Color.fromRGB(65, 252, 3), 1);
    					      ent.getWorld().spawnParticle(Particle.REDSTONE,ent.getLocation(),10, 0.1, 0.1, 0.1, dustOptions);	
    					}
    					if(i == 5) {
    						 DustOptions dustOptions = new DustOptions(Color.fromRGB(3, 103, 252), 1);
    					      ent.getWorld().spawnParticle(Particle.REDSTONE,ent.getLocation(),10, 0.1, 0.1, 0.1, dustOptions);	
    					}
    					if(i == 6) {
    						 DustOptions dustOptions = new DustOptions(Color.fromRGB(144, 3, 252), 1);
    					      ent.getWorld().spawnParticle(Particle.REDSTONE,ent.getLocation(),10, 0.1, 0.1, 0.1, dustOptions);	
    					}
    				}

    			}catch(NullPointerException x) {
    				
    			}
		}
	}, 0L, 1L); //0 Tick initial delay, 20 Tick (1 Second) between repeats
	
}
	
}
























