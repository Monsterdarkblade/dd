package me.nate.powercrystals;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class MindStone implements Listener{

	@EventHandler(ignoreCancelled = true)
	public void onHit(EntityDamageByEntityEvent e) {
		
		if(e.getDamager() instanceof Player) {
			Player player = (Player) e.getDamager();
			if(e.getEntity() instanceof Damageable) {
				if(e.getEntity() instanceof LivingEntity) {
					if(!(e.getEntity() instanceof ArmorStand)) {
					Entity ent = e.getEntity();
					
					if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.mind)) {
						
					int i = (int)(Math.random() * 100 + 1);
					if(i <= Config.mindStoneStunChance()) {
					
					((LivingEntity) ent).addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100 , 9));
					DustOptions dustOptions = new DustOptions(Color.fromRGB(250, 243, 37), 1);
				      ent.getWorld().spawnParticle(Particle.REDSTONE,ent.getLocation().add(0,1,0),50, 0.5, 0.5, 0.5, dustOptions);	
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1F, 1F);

					
						}
					}
					
						
						
				}
			}
		}
	}
}
	
	public static void startMindRunnable() {
		
	Bukkit.getScheduler().scheduleSyncRepeatingTask(InfinityStones.getPlugin(InfinityStones.class), new Runnable() {
		@Override
		public void run() {
			if(Config.nightvVisionAbility()) {
			for(Player player : Bukkit.getServer().getOnlinePlayers()) {
				if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.mind)) {
					player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 240 , 0));
					
				}
			  }
			}
		}
	}, 0L, 20L); //0 Tick initial delay, 20 Tick (1 Second) between repeats
	
	
	}
	
	
	}

