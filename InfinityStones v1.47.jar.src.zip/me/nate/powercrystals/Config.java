package me.nate.powercrystals;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.inventory.ItemStack;

public class Config {

private static InfinityStones main;
	
	public Config(InfinityStones main) {
		Config.main = main;
		
		main.getConfig().options().copyDefaults();
		main.saveDefaultConfig();
		
	}
	
	public static void reloadConfig() {
		main.reloadConfig();
	}
	
	
	//Game Settings
	public static boolean dropStonesOnDeath() {return main.getConfig().getBoolean("drop-stones-on-death");}
	public static boolean deleteStonesOnDeath() {return main.getConfig().getBoolean("delete-stones-on-death");}
	public static boolean showParticles() {return main.getConfig().getBoolean("show-particles");}
	@SuppressWarnings("unchecked")
	public static ArrayList<World> disabledWorlds(){
		ArrayList<World> world = new ArrayList<World>();
		List<String> strings = (List<String>) main.getConfig().getList("disabled-worlds");
		
		for(String s: strings) {
			if(Bukkit.getWorld(s) != null) {
				world.add(Bukkit.getWorld(s));
			}
		}
				
				return world;
		}
	
	
	public static ArrayList<Material> itemMaterial() {
		List<Material> mats = new ArrayList<Material>();
		for(String s : main.getConfig().getStringList("items.material")) {
			mats.add(Material.valueOf(s.toUpperCase()));
		}
		return (ArrayList<Material>) mats;
	}
	
	public static List<String> itemName() { return main.getConfig().getStringList("items.name"); }
	public static List<String> itemLocalizedName() { return main.getConfig().getStringList("items.localized-name"); }
	
	//POWER
	public static double powerStoneBeamDamage(){return main.getConfig().getDouble("power-stone-beam-damage");}
	public static int powerStoneBeamFireTicks() {return main.getConfig().getInt("power-stone-beam-fireticks");}
	public static double powerStoneDamageMultiplier(){return main.getConfig().getDouble("power-stone-damage-multiplier");}
	public static boolean powerBeam() {return main.getConfig().getBoolean("power-beam");}
	public static int powerBeamCooldown(){return main.getConfig().getInt("power-beam-cooldown");}
	public static boolean powerBeamDamagesPlayers() {return main.getConfig().getBoolean("power-beam-damages-players");}

	
	//REALITY
	public static double realityStoneDamageReduction() {return main.getConfig().getDouble("reality-stone-damage-reduction");}
	public static boolean speedAbility() {return main.getConfig().getBoolean("speed-ability");}
	public static int speedLevel() { return main.getConfig().getInt("speed-level");}
	
	//SPACE
	public static int spaceStoneTeleportCooldown() {return main.getConfig().getInt("space-stone-teleport-cooldown");}
	public static boolean doubleJump() {return main.getConfig().getBoolean("double-jump");}
	public static double doubleJumpVelocityMultiplier(){return main.getConfig().getDouble("double-jump-velocity-multiplier");}
	public static double doubleJumpYBoost(){return main.getConfig().getDouble("double-jump-y-boost");}
	public static boolean teleportAbility() {return main.getConfig().getBoolean("teleport-ability");}

	
	
	//MIND
	public static int mindStoneStunChance() {return main.getConfig().getInt("mind-stone-stun-chance");}
	public static boolean nightvVisionAbility() {return main.getConfig().getBoolean("night-vision-ability");}

	
	//SOUL
	public static int soulStoneChokeChance() {return main.getConfig().getInt("soul-stone-choke-chance");}
	public static boolean absorbtionAbility() {return main.getConfig().getBoolean("absorbtion-ability");}

	
	//TIME
	public static boolean luckAbility() {return main.getConfig().getBoolean("luck-ability");}
	public static boolean slowFallAbility() {return main.getConfig().getBoolean("slow-fall-ability");}
	public static int luckLevel() { return main.getConfig().getInt("luck-level");}

	
	//All Stones
	public static double allStonesPowerBeamDamage() {return main.getConfig().getDouble("all-stone-power-beam-damage");}
	public static int allStonesPowerBeamFireticks() {return main.getConfig().getInt("all-stone-power-beam-fireticks");}
	public static boolean allPowerBeam() {return main.getConfig().getBoolean("all-power-beam");}


	//MESSAGES
	
	public static String prefix() {return main.getConfig().getString("prefix");}

	public static String alreadyEquipped() {return main.getConfig().getString("already-equipped");}
	public static String spaceStoneTeleport() {return main.getConfig().getString("space-stone-teleport");}
	public static String invalidStoneType() {return main.getConfig().getString("invalid-stone-type");}
	public static String noPermission() {return main.getConfig().getString("no-permission");}
	public static String teleportCooldownMessage() {return main.getConfig().getString("teleport-cooldown-message");}


	//Titles
	public static String theEndIsNear() {return main.getConfig().getString("the-end-is-near");}
	public static String theEndIsNearSubtitle() {return main.getConfig().getString("the-end-is-near-subtitle");}
	public static String powerStoneEquip() {return main.getConfig().getString("power-stone-equip");}
	public static String powerStoneEquipSubtitle() {return main.getConfig().getString("power-stone-equip-subtitle");}
	public static String realityStoneEquip() {return main.getConfig().getString("reality-stone-equip");}
	public static String realityStoneEquipSubtitle() {return main.getConfig().getString("reality-stone-equip-subtitle");}
	public static String mindStoneEquip() {return main.getConfig().getString("mind-stone-equip");}
	public static String mindStoneEquipSubtitle() {return main.getConfig().getString("mind-stone-equip-subtitle");}
	public static String spaceStoneEquip() {return main.getConfig().getString("space-stone-equip");}
	public static String spaceStoneEquipSubtitle() {return main.getConfig().getString("space-stone-equip-subtitle");}
	public static String timeStoneEquip() {return main.getConfig().getString("time-stone-equip");}
	public static String timeStoneEquipSubtitle() {return main.getConfig().getString("time-stone-equip-subtitle");}
	public static String soulStoneEquip() {return main.getConfig().getString("soul-stone-equip");}
	public static String soulStoneEquipSubtitle() {return main.getConfig().getString("soul-stone-equip-subtitle");}

	//Items
	public static String powerStoneName() {return main.getConfig().getString("power-stone-name");}
	public static String timeStoneName() {return main.getConfig().getString("time-stone-name");}
	public static String spaceStoneName() {return main.getConfig().getString("space-stone-name");}
	public static String mindStoneName() {return main.getConfig().getString("mind-stone-name");}
	public static String realityStoneName() {return main.getConfig().getString("reality-stone-name");}
	public static String soulStoneName() {return main.getConfig().getString("soul-stone-name");}

	public static ItemStack powerStoneItem() {
		if(main.getConfig().getString("power-stone-item").length() < 150)
		return new ItemBuilder(Material.valueOf(main.getConfig().getString("power-stone-item").toUpperCase())).name(powerStoneName()).build();;
		return new ItemBuilder(Material.PLAYER_HEAD).makeSkull(main.getConfig().getString("power-stone-item")).name(powerStoneName()).build();
		}
	
	public static ItemStack timeStoneItem() {
		if(main.getConfig().getString("time-stone-item").length() < 150)
		return new ItemBuilder(Material.valueOf(main.getConfig().getString("time-stone-item").toUpperCase())).name(timeStoneName()).build();
		return new ItemBuilder(Material.PLAYER_HEAD).makeSkull(main.getConfig().getString("time-stone-item")).name(timeStoneName()).build();
		}
	
	public static ItemStack spaceStoneItem() {
		if(main.getConfig().getString("space-stone-item").length() < 150)
			return new ItemBuilder(Material.valueOf(main.getConfig().getString("space-stone-item").toUpperCase())).name(spaceStoneName()).build();
			return new ItemBuilder(Material.PLAYER_HEAD).makeSkull(main.getConfig().getString("space-stone-item")).name(spaceStoneName()).build();
	}
	
	public static ItemStack mindStoneItem() {
		if(main.getConfig().getString("mind-stone-item").length() < 150)
			return new ItemBuilder(Material.valueOf(main.getConfig().getString("mind-stone-item").toUpperCase())).name(mindStoneName()).build();
			return new ItemBuilder(Material.PLAYER_HEAD).makeSkull(main.getConfig().getString("mind-stone-item")).name(mindStoneName()).build();
	}
	
	public static ItemStack realityStoneItem() {
		if(main.getConfig().getString("reality-stone-item").length() < 150)
			return new ItemBuilder(Material.valueOf(main.getConfig().getString("reality-stone-item").toUpperCase())).name(realityStoneName()).build();
			return new ItemBuilder(Material.PLAYER_HEAD).makeSkull(main.getConfig().getString("reality-stone-item")).name(realityStoneName()).build();
	}
	
	public static ItemStack soulStoneItem() {
		if(main.getConfig().getString("soul-stone-item").length() < 150)
			return new ItemBuilder(Material.valueOf(main.getConfig().getString("soul-stone-item").toUpperCase())).name(soulStoneName()).build();
			return new ItemBuilder(Material.PLAYER_HEAD).makeSkull(main.getConfig().getString("soul-stone-item")).name(soulStoneName()).build();
	}
	
	//GUI
	
	public static String guiName() {return main.getConfig().getString("gauntlet-gui-name");}

	public static int spaceStoneSlot() {return main.getConfig().getInt("space-stone-slot");}
	public static int realityStoneSlot() {return main.getConfig().getInt("reality-stone-slot");}
	public static int powerStoneSlot() {return main.getConfig().getInt("power-stone-slot");}
	public static int mindStoneSlot() {return main.getConfig().getInt("mind-stone-slot");}
	public static int timeStoneSlot() {return main.getConfig().getInt("time-stone-slot");}
	public static int soulStoneSlot() {return main.getConfig().getInt("soul-stone-slot");}

	public static Material fillMaterial() {return Material.valueOf(main.getConfig().getString("fill-material"));}

	
	
	//item lores
	
	@SuppressWarnings("unchecked")
	public static List<String> guiPowerStoneLore(){return (List<String>) main.getConfig().getList("power-stone-lore");}
	@SuppressWarnings("unchecked")
	public static List<String> guiSoulStoneLore(){return (List<String>) main.getConfig().getList("soul-stone-lore");}
	@SuppressWarnings("unchecked")
	public static List<String> guiMindStoneLore(){return (List<String>) main.getConfig().getList("mind-stone-lore");}
	@SuppressWarnings("unchecked")
	public static List<String> guiTimeStoneLore(){return (List<String>) main.getConfig().getList("time-stone-lore");}
	@SuppressWarnings("unchecked")
	public static List<String> guiRealityStoneLore(){return (List<String>) main.getConfig().getList("reality-stone-lore");}
	@SuppressWarnings("unchecked")
	public static List<String> guiSpaceStoneLore(){return (List<String>) main.getConfig().getList("space-stone-lore");}


	
	
	
	
}
