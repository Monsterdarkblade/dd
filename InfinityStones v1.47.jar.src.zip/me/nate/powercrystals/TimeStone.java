package me.nate.powercrystals;

import java.util.HashMap;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class TimeStone implements Listener{
		
	public static HashMap<UUID, Long> cooldown = new HashMap<>();


	
	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
	Player player = e.getPlayer();
		if(e.getItem() != null) {
			if(isGauntletItem(e.getItem())) {
	        if (e.getAction() == Action.RIGHT_CLICK_AIR) {
	        	
	        	
	        	if(cooldown.containsKey(player.getUniqueId())) { //in cooldown
	    			if(System.currentTimeMillis() < cooldown.get(player.getUniqueId())) {

	    				int time = (int) ((cooldown.get(player.getUniqueId()) - System.currentTimeMillis()))/1000;
	    				
	    				player.sendMessage(ChatColor.translateAlternateColorCodes('&', Config.teleportCooldownMessage().replaceAll("%time%", "" + time) ));
	    				// IN COOLDOWN ---- DO NOTHING
	    				return;
	    			}
	    			
	    			
	    		}
	        	
	        if(Config.teleportAbility()) {
			if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.space)) {

                Block block = e.getPlayer().getTargetBlock(null, 75);
				
				 Location location = new Location(block.getWorld(), block.getX() + 0.5, block.getY() + 1, block.getZ() + 0.5, e.getPlayer().getLocation().getYaw(), e.getPlayer().getLocation().getPitch());

				 
                 while (location.getBlock().getType() != Material.AIR || location.getBlock().getRelative(0, 1, 0).getType() != Material.AIR) {
                     if (location.getBlockY() == 256) return;
                     location.add(0, 1, 0);
                 }
                 
                 	if(!(block.getType() == Material.AIR)) {
                 	 e.getPlayer().teleport(location);
                     e.getPlayer().playSound(e.getPlayer().getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1, 1);
                     player.sendMessage(color(Config.spaceStoneTeleport()));
                     
                     long now = System.currentTimeMillis(); long thirtyMillis = (Config.spaceStoneTeleportCooldown() * 1000); long nowPlusThirty = now + thirtyMillis;
                     
					  cooldown.put(player.getUniqueId(), nowPlusThirty);
                     
                 	}
				
				}
			    
	        	}
	        }
		}}
	}
	
	public static boolean isGauntletItem(ItemStack item) {
		if(item == null) return false;
		
		for(Material mat : Config.itemMaterial()) {
			if(item.getType().equals(mat)) return true;
		}
		
		if(!item.hasItemMeta()) return false;
		
		for(String str : Config.itemName()) {
			if(item.getItemMeta().getDisplayName().equals(color(str))) return true;
		}

		for(String str : Config.itemLocalizedName()) {
			if(item.getItemMeta().getLocalizedName().equals(color(str))) return true;
		}
		return false;
	}
	
	
	public static void startTimeRunnable() {
		
	Bukkit.getScheduler().scheduleSyncRepeatingTask(InfinityStones.getPlugin(InfinityStones.class), new Runnable() {
		@Override
		public void run() {
			for(Player player : Bukkit.getServer().getOnlinePlayers()) {
				if(Config.luckAbility()) {
				if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.time)) {
					player.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, 21 , (Config.luckLevel() - 1)));
				}
			}
		}}
	}, 0L, 20L); //0 Tick initial delay, 20 Tick (1 Second) between repeats
	
	
	}
	
	public static String color(String s) {return ChatColor.translateAlternateColorCodes('&', s);}
}
























