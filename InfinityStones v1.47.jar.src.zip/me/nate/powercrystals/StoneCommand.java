package me.nate.powercrystals;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StoneCommand implements CommandExecutor{
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		
			if(label.equalsIgnoreCase("gauntlet")) {
				if(sender instanceof Player) {
				Player player = (Player) sender;
				new StonesGUI(player);
				}else {
					sender.sendMessage("You can only use this command in game!");
				}
			} else if(label.equalsIgnoreCase("getstone")) {
				
				try {
					if(args.length >= 2) {
						Player player = Bukkit.getPlayer(args[1]);
							
							if(sender.hasPermission("infinitystones.getstones")) {
							if(args[0].equalsIgnoreCase("all")) {	
								player.getInventory().addItem(new ItemBuilder(Config.mindStoneItem()).name(Config.mindStoneName()).addGlow().build());
								player.getInventory().addItem(new ItemBuilder(Config.realityStoneItem()).name(Config.realityStoneName()).addGlow().build());
								player.getInventory().addItem(new ItemBuilder(Config.soulStoneItem()).name(Config.soulStoneName()).addGlow().build());
								player.getInventory().addItem(new ItemBuilder(Config.timeStoneItem()).name(Config.timeStoneName()).addGlow().build());
								player.getInventory().addItem(new ItemBuilder(Config.spaceStoneItem()).name(Config.spaceStoneName()).addGlow().build());
								player.getInventory().addItem(new ItemBuilder(Config.powerStoneItem()).name(Config.powerStoneName()).addGlow().build());
							}
							else if(args[0].equalsIgnoreCase("space")) {
								player.getInventory().addItem(new ItemBuilder(Config.spaceStoneItem()).name(Config.spaceStoneName()).addGlow().build());

							}
							else if(args[0].equalsIgnoreCase("mind")) {
								player.getInventory().addItem(new ItemBuilder(Config.mindStoneItem()).name(Config.mindStoneName()).addGlow().build());

							}
							else if(args[0].equalsIgnoreCase("reality")) {
								player.getInventory().addItem(new ItemBuilder(Config.realityStoneItem()).name(Config.realityStoneName()).addGlow().build());

							}
							else if(args[0].equalsIgnoreCase("soul")) {
								player.getInventory().addItem(new ItemBuilder(Config.soulStoneItem()).name(Config.soulStoneName()).addGlow().build());

							}
							else if(args[0].equalsIgnoreCase("time")) {
								player.getInventory().addItem(new ItemBuilder(Config.timeStoneItem()).name(Config.timeStoneName()).addGlow().build());

							}
							else if(args[0].equalsIgnoreCase("power")) {
								player.getInventory().addItem(new ItemBuilder(Config.powerStoneItem()).name(Config.powerStoneName()).addGlow().build());

							}
							else if(args[0].equalsIgnoreCase("gauntlet")) {
								player.getInventory().addItem(new ItemBuilder(Material.HONEYCOMB).name("&cInf&6ini&ety &aGau&9ntl&5et").addGlow().localisedName("gauntlet").build());

							}
							
							
							
							
							}else {
								sender.sendMessage(color(Config.prefix() + "&cYou can't use this command!"));
							}
						
						 }else {
							 sender.sendMessage(color(Config.prefix() + "&cImproper Usage! Use: /getstone <stone> <player>"));
						 }
				} catch(NullPointerException x) {
					sender.sendMessage(color("&cPlayer not found!"));
					
				}
				
				
				
				
			} else if(label.equalsIgnoreCase("removestone")) {

				if(args.length >= 2) {
					if(sender.hasPermission("infinitystones.removestones")) {
						
						try {
					Player target = Bukkit.getPlayer(args[0]);	
					
					if(args[1].equalsIgnoreCase("mind")) {
						InfinityStones.mind.put(target.getUniqueId().toString(), false);
						sender.sendMessage(color("&7Removed the &eMind Stone&7 from &6" + target.getName()));
					}
					else if(args[1].equalsIgnoreCase("space")) {
						InfinityStones.space.put(target.getUniqueId().toString(), false);
						sender.sendMessage(color("&7Removed the &9Space Stone&7 from &6" + target.getName()));
						target.setAllowFlight(false);
					}
					else if(args[1].equalsIgnoreCase("time")) {
						InfinityStones.time.put(target.getUniqueId().toString(), false);
						sender.sendMessage(color("&7Removed the &aTime Stone&7 from &6" + target.getName()));

					}
					else if(args[1].equalsIgnoreCase("power")) {
						InfinityStones.power.put(target.getUniqueId().toString(), false);
						sender.sendMessage(color("&7Removed the &5Power Stone&7 from &6" + target.getName()));

					}
					else if(args[1].equalsIgnoreCase("reality")) {
						InfinityStones.reality.put(target.getUniqueId().toString(), false);
						sender.sendMessage(color("&7Removed the &cReality Stone&7 from &6" + target.getName()));

					}
					else if(args[1].equalsIgnoreCase("soul")) {
						InfinityStones.soul.put(target.getUniqueId().toString(), false);
						sender.sendMessage(color("&7Removed the &6Soul Stone&7 from &6" + target.getName()));

					}
					else if(args[1].equalsIgnoreCase("all")) {
						InfinityStones.soul.put(target.getUniqueId().toString(), false);
						InfinityStones.mind.put(target.getUniqueId().toString(), false);
						InfinityStones.space.put(target.getUniqueId().toString(), false);
						InfinityStones.time.put(target.getUniqueId().toString(), false);
						InfinityStones.power.put(target.getUniqueId().toString(), false);
						InfinityStones.reality.put(target.getUniqueId().toString(), false);

						sender.sendMessage(color("&7Removed &cA&6ll &eSt&ao&9n&5es&7 from &6" + target.getName()));

					}
					else {
						sender.sendMessage(color("&6" + args[1] + Config.invalidStoneType()));
					}
						} catch(NullPointerException x) {
							sender.sendMessage(color("&cCouldn't find the player &6" + args[0] + "&c!"));
						}
						
					} else {
						sender.sendMessage(color(Config.noPermission()));
					}
				} else {
					sender.sendMessage(color(Config.prefix() + "&cImproper Usage! Use: /removestone <player> <stone>"));
				}
			} else if(label.equalsIgnoreCase("equipstone")) {

				if(args.length >= 2) {
					if(sender.hasPermission("infinitystones.equipstones")) {
						
						try {
					Player target = Bukkit.getPlayer(args[0]);	
					
					if(args[1].equalsIgnoreCase("mind")) {
						InfinityStones.mind.put(target.getUniqueId().toString(), true);
						sender.sendMessage(color(Config.prefix() + "&7Equipped the &eMind Stone&7 for &6" + target.getName()));
					}
					else if(args[1].equalsIgnoreCase("space")) {
						InfinityStones.space.put(target.getUniqueId().toString(), true);
						sender.sendMessage(color(Config.prefix() + "&7Equipped the &9Space Stone&7 for &6" + target.getName()));

					}
					else if(args[1].equalsIgnoreCase("time")) {
						InfinityStones.time.put(target.getUniqueId().toString(), true);
						sender.sendMessage(color(Config.prefix() +"&7Equipped the &aTime Stone&7 for &6" + target.getName()));

					}
					else if(args[1].equalsIgnoreCase("power")) {
						InfinityStones.power.put(target.getUniqueId().toString(), true);
						sender.sendMessage(color(Config.prefix() +"&7Equipped the &5Power Stone&7 for &6" + target.getName()));

					}
					else if(args[1].equalsIgnoreCase("reality")) {
						InfinityStones.reality.put(target.getUniqueId().toString(), true);
						sender.sendMessage(color(Config.prefix() +"&7Equipped the &cReality Stone&7 for &6" + target.getName()));

					}
					else if(args[1].equalsIgnoreCase("soul")) {
						InfinityStones.soul.put(target.getUniqueId().toString(), true);
						sender.sendMessage(color(Config.prefix() +"&7Equipped the &6Soul Stone&7 for &6" + target.getName()));

					}
					else if(args[1].equalsIgnoreCase("all")) {
						InfinityStones.soul.put(target.getUniqueId().toString(), true);
						InfinityStones.mind.put(target.getUniqueId().toString(), true);
						InfinityStones.space.put(target.getUniqueId().toString(), true);
						InfinityStones.time.put(target.getUniqueId().toString(), true);
						InfinityStones.power.put(target.getUniqueId().toString(), true);
						InfinityStones.reality.put(target.getUniqueId().toString(), true);

						sender.sendMessage(color(Config.prefix() +"&7Equipped &cA&6ll &eSt&ao&9n&5es&7 for &6" + target.getName()));

					}else {
						sender.sendMessage(color("&6" + args[1] + Config.invalidStoneType()));
					}
						} catch(NullPointerException x) {
							sender.sendMessage(color(Config.prefix() +"&cCouldn't find the player &6" + args[0] + "&c!"));
						}
						
					} else {
						sender.sendMessage(color(Config.noPermission()));
					}
				} else {
					sender.sendMessage(color(Config.prefix() +"&cImproper Usage! Use: /equipstone <player> <stone>"));
				}
			} else if(label.equalsIgnoreCase("infinitystones")) {
				if(sender instanceof Player) {
				Player player = (Player) sender;
				player.sendMessage(color("&6-----------------&f[ &cIn&6fi&eni&aty &bSt&9on&5es&f ]&6-----------------"));
				player.sendMessage(color("&7Made by Natecb13                                          v" + InfinityStones.getInstance().getDescription().getVersion()));
				player.sendMessage(" ");
				player.sendMessage(color("&6Spigot Page:&7 https://www.spigotmc.org/resources/authors/natecb13.956518/ "));
				player.sendMessage(color("&d&lPlugin Support Discord: &7https://discord.gg/tPzaPKPmNU"));
				player.sendMessage(" ");
				player.sendMessage(color("&6&lCommands:"));
				player.sendMessage(color("&b&l/gauntlet&7 - opens the infinity gauntlet."));
				if(player.hasPermission("infninitystones.getstone")){player.sendMessage(color("&b&l/getstone <stone>&7 - used to give the player the infinity stones"));player.sendMessage(" ");}
				if(player.hasPermission("infinitystones.removestone")){player.sendMessage(color("&b&l/removestone <player> <stone>&7 - used to remove stones from a player"));player.sendMessage(" ");}
				if(player.hasPermission("infinitystones.equipstone")){player.sendMessage(color("&b&l/equipstone <player> <stone>&7 - used to equip stones for a player"));player.sendMessage(" ");}
				player.sendMessage(color("&6------------------------------------------------"));
				} 
			}
			else if(label.equalsIgnoreCase("isreload")) {
				
				if(sender.hasPermission("infinitystones.reload")) {
					Config.reloadConfig();
					sender.sendMessage(color(Config.prefix() + "&aConfig reloaded!"));
				} else {
					sender.sendMessage(Config.noPermission());
				}
				
			}
		 
		return false;
	}
	
	public String color(String s) {return ChatColor.translateAlternateColorCodes('&', s);}
}
