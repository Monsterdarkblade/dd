package me.nate.powercrystals;

import java.util.Map;

import org.bukkit.Bukkit;

public class AutoSave {

	public static void AutoSaveStones() {
		Bukkit.getScheduler().scheduleSyncRepeatingTask(InfinityStones.getPlugin(InfinityStones.class), new Runnable() {
			@Override
			public void run() {


				Map<String, Boolean> power = InfinityStones.power;
				Map<String, Boolean> time = InfinityStones.time;
				Map<String, Boolean> mind = InfinityStones.mind;
				Map<String, Boolean> space = InfinityStones.space;
				Map<String, Boolean> reality = InfinityStones.reality;
				Map<String, Boolean> soul = InfinityStones.soul;
				
				Bukkit.getScheduler().runTaskAsynchronously(InfinityStones.getPlugin(InfinityStones.class), new Runnable(){
				    @Override
				    public void run() {
				       
				    	for(Map.Entry<String, Boolean> entry: power.entrySet()) {
							InfinityStones.getInstance().data.getConfig().set("power." + entry.getKey(), entry.getValue());
						}
						for(Map.Entry<String, Boolean> entry: time.entrySet()) {
							InfinityStones.getInstance().data.getConfig().set("time." + entry.getKey(), entry.getValue());
						}
						for(Map.Entry<String, Boolean> entry: mind.entrySet()) {
							InfinityStones.getInstance().data.getConfig().set("mind." + entry.getKey(), entry.getValue());
						}
						for(Map.Entry<String, Boolean> entry: space.entrySet()) {
							InfinityStones.getInstance().data.getConfig().set("space." + entry.getKey(), entry.getValue());
						}
						for(Map.Entry<String, Boolean> entry: reality.entrySet()) {
							InfinityStones.getInstance().data.getConfig().set("reality." + entry.getKey(), entry.getValue());
						}
						for(Map.Entry<String, Boolean> entry: soul.entrySet()) {
							InfinityStones.getInstance().data.getConfig().set("soul." + entry.getKey(), entry.getValue());
						}
						
						InfinityStones.getInstance().data.saveConfig();
				    	
				    }
				});
				
				
				
			}
		}, 0L, 1200L); //0 Tick initial delay, 20 Tick (1 Second) between repeats
	}
	
}
