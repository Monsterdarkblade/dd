package me.nate.powercrystals;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

public class Particles {

	static double angle = 0;
	public void createParticles() {
	
	if(Config.showParticles()) {	
	Bukkit.getScheduler().scheduleSyncRepeatingTask(InfinityStones.getPlugin(InfinityStones.class), new Runnable() {
		
		@Override
		public void run() {
			
			
			for(Player player: Bukkit.getServer().getOnlinePlayers()) {
				if(player.hasPotionEffect(PotionEffectType.INVISIBILITY)) return;
				if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.power)) {
				
					float x = (float) (0.75*Math.sin(angle));
					float z = (float) (0.75*Math.cos(angle));
					
					Location loc = player.getLocation();
					Location loc2 = new Location(player.getWorld(), loc.getX() + x, loc.getY() + 0.1 ,loc.getZ() + z);
					DustOptions dustOptions = new DustOptions(Color.fromRGB(100, 0, 194), 1);
				    player.getWorld().spawnParticle(Particle.REDSTONE, loc2 , 1 , dustOptions);
			
				
					}
				if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.time)) {
					
					float x = (float) (0.75*Math.sin(angle + 1));
					float z = (float) (0.75*Math.cos(angle + 1));
					
					Location loc = player.getLocation();
					Location loc2 = new Location(player.getWorld(), loc.getX() + x, loc.getY() + 0.2 ,loc.getZ() + z);
					DustOptions dustOptions = new DustOptions(Color.fromRGB(80, 227, 73), 1);
				    player.getWorld().spawnParticle(Particle.REDSTONE, loc2 , 1 , dustOptions);
			
					
					}
				
				if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.mind)) {
					
					float x = (float) (0.75*Math.sin(angle + 2));
					float z = (float) (0.75*Math.cos(angle + 2));
					
					Location loc = player.getLocation();
					Location loc2 = new Location(player.getWorld(), loc.getX() + x, loc.getY() + 0.3 ,loc.getZ() + z);
					DustOptions dustOptions = new DustOptions(Color.fromRGB(255, 234, 43), 1);
				    player.getWorld().spawnParticle(Particle.REDSTONE, loc2 , 1 , dustOptions);
					}
				
				if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.space)) {
					
					float x = (float) (0.75*Math.sin(angle + 3));
					float z = (float) (0.75*Math.cos(angle + 3));
					
					Location loc = player.getLocation();
					Location loc2 = new Location(player.getWorld(), loc.getX() + x, loc.getY() + 0.4 ,loc.getZ() + z);
					DustOptions dustOptions = new DustOptions(Color.fromRGB(48, 30, 250), 1);
				    player.getWorld().spawnParticle(Particle.REDSTONE, loc2 , 1 , dustOptions);
			
					
					}
				if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.reality)) {
					
					float x = (float) (0.75*Math.sin(angle + 4));
					float z = (float) (0.75*Math.cos(angle + 4));
					
					Location loc = player.getLocation();
					Location loc2 = new Location(player.getWorld(), loc.getX() + x, loc.getY() + 0.5 ,loc.getZ() + z);
					DustOptions dustOptions = new DustOptions(Color.fromRGB(194, 0, 0), 1);
				    player.getWorld().spawnParticle(Particle.REDSTONE, loc2 , 1 , dustOptions);
			
					}
				if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.soul)) {
					
					float x = (float) (0.75*Math.sin(angle + 5));
					float z = (float) (0.75*Math.cos(angle + 5));
					
					Location loc = player.getLocation();
					Location loc2 = new Location(player.getWorld(), loc.getX() + x, loc.getY() + 0.6 ,loc.getZ() + z);
					DustOptions dustOptions = new DustOptions(Color.fromRGB(227, 151, 0), 1);
				    player.getWorld().spawnParticle(Particle.REDSTONE, loc2 , 1 , dustOptions);
			
					}
						
				}
			
			
			
			angle = angle + 0.15;
					if(angle > 360) {
						angle = 0;
						}
					  
				
		} 
	}, 0L, 1L); //0 Tick initial delay, 20 Tick (1 Second) between repeats
	
	}
	}
	
}
