package me.nate.powercrystals;

import java.util.HashMap;

import org.bukkit.entity.Damageable;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class PowerStone implements Listener{

	@EventHandler(ignoreCancelled = true)
	public void onHit(EntityDamageByEntityEvent e) {
		if(e.getEntity() instanceof Damageable) {
			if(e.getDamager()instanceof Player) {
				Player player = (Player) e.getDamager();
				
				if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.power)) {
					
					Double d = e.getDamage() *( 1 + Config.powerStoneDamageMultiplier());
					e.setDamage(d);
					
					
					
				}
				
				
			}
			
			
			
		}
	}
	
	@EventHandler(ignoreCancelled = true)
	public void onDamage(EntityDamageEvent e) {
		if(e.getEntity() instanceof Player) {
			Player player = (Player) e.getEntity();
			if(InfinityStones.hasStone(player, (HashMap<String, Boolean>) InfinityStones.reality)) {
			Double amt = e.getDamage() * (1 - Config.realityStoneDamageReduction());
			e.setDamage(amt);
			}
		}
		
		// 10  -> 10 * (1-0.9) ==> 
		
	}
	
	
}
