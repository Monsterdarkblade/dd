package me.nate.powercrystals;

import java.util.HashMap;

import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryEvent;
import org.bukkit.event.inventory.InventoryInteractEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import me.nate.powercrystals.Files.DataManager;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;




public class InfinityStones extends JavaPlugin implements Listener{

	
	public static Map<String, Boolean> power = new HashMap<String, Boolean>();
	public static Map<String, Boolean> time = new HashMap<String, Boolean>();
	public static Map<String, Boolean> mind = new HashMap<String, Boolean>();
	public static Map<String, Boolean> space = new HashMap<String, Boolean>();
	public static Map<String, Boolean> reality = new HashMap<String, Boolean>();
	public static Map<String, Boolean> soul = new HashMap<String, Boolean>();


	Particles particles = new Particles();
	
	private static InfinityStones instance;
	
	public DataManager data;
	
	@Override 
	public void onEnable() {
		
		this.data = new DataManager(this);
		
		InfinityStones.instance = this;
		
		new Config(this);
		
		System.out.println("InfinityStones has been enabled!");
		
		Bukkit.getPluginManager().registerEvents(this, this);
		Bukkit.getPluginManager().registerEvents(new SpaceStone(), this);
		Bukkit.getPluginManager().registerEvents(new TimeStone(), this);
		Bukkit.getPluginManager().registerEvents(new SoulStone(), this);
		Bukkit.getPluginManager().registerEvents(new PowerStone(), this);
		Bukkit.getPluginManager().registerEvents(new MindStone(), this);
		Bukkit.getPluginManager().registerEvents(new RealityStone(), this);
		this.getCommand("getstone").setExecutor(new StoneCommand());
		this.getCommand("gauntlet").setExecutor(new StoneCommand());
		this.getCommand("removestone").setExecutor(new StoneCommand());
		this.getCommand("equipstone").setExecutor(new StoneCommand());
		this.getCommand("infinitystones").setExecutor(new StoneCommand());
		this.getCommand("isreload").setExecutor(new StoneCommand());
		
		this.getCommand("getstone").setTabCompleter(new StonesTabCompleter());

		if(Config.showParticles()) {
		particles.createParticles(); 
		}
		
		refreshStones();
		TimeStone.startTimeRunnable();
		MindStone.startMindRunnable();
		RealityStone.realityStone();
		RealityStone.realityStoneRunabble();;
		
		AutoSave.AutoSaveStones();
		
		
		data.saveDefaultConfig();
		
		if(data.getConfig().contains("power")) {
		this.restoreInvs();}
	
		//Bstats
		Metrics metrics = new Metrics(this, 10410);
	}
	
	@Override
	public void onDisable() {
	
		if(!(power.isEmpty())) {
			saveInvs();
		}
		
		
		data.saveConfig();
		
	}
	
	
	
	public static InfinityStones getInstance() {return instance;}
	
	
	 
	public void saveInvs() {

		for(Map.Entry<String, Boolean> entry: power.entrySet()) {
			data.getConfig().set("power." + entry.getKey(), entry.getValue());
		}
		for(Map.Entry<String, Boolean> entry: time.entrySet()) {
			data.getConfig().set("time." + entry.getKey(), entry.getValue());
		}
		for(Map.Entry<String, Boolean> entry: mind.entrySet()) {
			data.getConfig().set("mind." + entry.getKey(), entry.getValue());
		}
		for(Map.Entry<String, Boolean> entry: space.entrySet()) {
			data.getConfig().set("space." + entry.getKey(), entry.getValue());
		}
		for(Map.Entry<String, Boolean> entry: reality.entrySet()) {
			data.getConfig().set("reality." + entry.getKey(), entry.getValue());
		}
		for(Map.Entry<String, Boolean> entry: soul.entrySet()) {
			data.getConfig().set("soul." + entry.getKey(), entry.getValue());
		}
		
		data.saveConfig();
		
	}
	
	
	
	public void restoreInvs() {

		data.getConfig().getConfigurationSection("power").getKeys(false).forEach(key->{
			Boolean content = (Boolean) data.getConfig().get("power." + key);
			power.put(key, content);
		});
		data.getConfig().getConfigurationSection("time").getKeys(false).forEach(key->{
			Boolean content = (Boolean) data.getConfig().get("time." + key);
			time.put(key, content);
		});
		data.getConfig().getConfigurationSection("mind").getKeys(false).forEach(key->{
			Boolean content = (Boolean) data.getConfig().get("mind." + key);
			mind.put(key, content);
		});
		data.getConfig().getConfigurationSection("space").getKeys(false).forEach(key->{
			Boolean content = (Boolean) data.getConfig().get("space." + key);
			space.put(key, content);
		});
		data.getConfig().getConfigurationSection("reality").getKeys(false).forEach(key->{
			Boolean content = (Boolean) data.getConfig().get("reality." + key);
			reality.put(key, content);
		});
		data.getConfig().getConfigurationSection("soul").getKeys(false).forEach(key->{
			Boolean content = (Boolean) data.getConfig().get("soul." + key);
			soul.put(key, content);
		});
		
		
	}
	
	
	
	
	public void refreshStones() {
		for(Player player: Bukkit.getOnlinePlayers()) {
			String uuid = player.getUniqueId().toString();

			if(!(power.containsKey(uuid))) {
				power.put(uuid, false);
			}
			if(!(time.containsKey(uuid))) {
				time.put(uuid, false);
			}
			if(!(mind.containsKey(uuid))) {
				mind.put(uuid, false);
			}
			if(!(reality.containsKey(uuid))) {
				reality.put(uuid, false);
			}
			if(!(space.containsKey(uuid))) {
				space.put(uuid, false);
			}
			if(!(soul.containsKey(uuid))) {
				soul.put(uuid, false);
			}
		}
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		refreshStones();
	}
	
	public static boolean hasStone(Player player, HashMap<String, Boolean> map) {
		if(player.hasPermission("infinitystones.usestones")) {
		if(Config.disabledWorlds().contains(player.getWorld())) return false;
		if(map.containsKey(player.getUniqueId().toString())) {
			if(map.get(player.getUniqueId().toString())) {
			return true;
		}
		}
		
		}
		return false;
	}
	
	public static boolean hasAllStones(Player player) {
		String uuid = player.getUniqueId().toString();
		if(Config.disabledWorlds().contains(player.getWorld())) return false;
		if(power.get(uuid)){
			if(mind.get(uuid)) {
				if(reality.get(uuid)) {
					if(space.get(uuid)) {
						if(soul.get(uuid)) {
							if(time.get(uuid)) {
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
	
	
	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		Player player = e.getPlayer();
		String uuid = player.getUniqueId().toString();
		ItemStack item = e.getItem();
		if(item != null) {
			if(item.hasItemMeta()) {
			if(item.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', Config.powerStoneName()))) {
				e.setCancelled(true);
				if(power.get(uuid).equals(false)) {
					if(e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
						power.put(uuid, true);
						player.sendTitle(color(Config.powerStoneEquip()), color(Config.powerStoneEquipSubtitle()), 0, 40, 0);
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1F, 1F);
						particleCould(100, player.getLocation().add(0,1,0), Color.fromRGB(100, 0, 194), 0.5, 1 , 0.5);
						allStoneCheck(player);
						item.setAmount(item.getAmount() -1);
					}
				} else {
					player.sendMessage(color(Config.prefix() + Config.alreadyEquipped()));
				}		
			}
			else if(item.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', Config.timeStoneName()))) {
				e.setCancelled(true);
				if(time.get(uuid).equals(false)) {
					if(e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
						time.put(uuid, true);
						player.sendTitle(color(Config.timeStoneEquip()), color(Config.timeStoneEquipSubtitle()), 0, 40, 20);
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1F, 1F);
						particleCould(100, player.getLocation().add(0,1,0), Color.fromRGB(80, 227, 73), 0.5, 1 , 0.5);
						allStoneCheck(player);
						item.setAmount(item.getAmount() -1);
					}
				} else {
					player.sendMessage(color(Config.prefix() + Config.alreadyEquipped()));
				}		
			}
			else if(item.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', Config.mindStoneName()))) {
				e.setCancelled(true);
				if(mind.get(uuid).equals(false)) {
					if(e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
						mind.put(uuid, true);
						player.sendTitle(color(Config.mindStoneEquip()), color(Config.mindStoneEquipSubtitle()), 0, 40, 20);
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1F, 1F);
						particleCould(100, player.getLocation().add(0,1,0),Color.fromRGB(255, 234, 43), 0.5, 1 , 0.5);
						allStoneCheck(player);
						item.setAmount(item.getAmount() -1);
					}
				} else {
					player.sendMessage(color(Config.prefix() + Config.alreadyEquipped()));
					}		
				}
			else if(item.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', Config.spaceStoneName()))) {
				e.setCancelled(true);
				if(space.get(uuid).equals(false)) {
					if(e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
						space.put(uuid, true);
						player.sendTitle(color(Config.spaceStoneEquip()), color(Config.spaceStoneEquipSubtitle()), 0, 40, 20);
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1F, 1F);
						particleCould(100, player.getLocation().add(0,1,0),Color.fromRGB(48, 30, 250), 0.5, 1 , 0.5);
						allStoneCheck(player);
						item.setAmount(item.getAmount() -1);
					}
				} else {
					player.sendMessage(color(Config.prefix() + Config.alreadyEquipped()));
					}		
				}
			
			else if(item.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', Config.realityStoneName()))) {
				e.setCancelled(true);
				if(reality.get(uuid).equals(false)) {
					if(e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
						reality.put(uuid, true);
						player.sendTitle(color(Config.realityStoneEquip()), color(Config.realityStoneEquipSubtitle()), 0, 40, 20);
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1F, 1F);
						particleCould(100, player.getLocation().add(0,1,0),Color.fromRGB(194, 0, 0), 0.5, 1 , 0.5);
						allStoneCheck(player);
						item.setAmount(item.getAmount() -1);
					}
				} else {
					player.sendMessage(color(Config.prefix() + Config.alreadyEquipped()));
					}		
				}
			else if(item.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', Config.soulStoneName()))) {
				e.setCancelled(true);
				if(soul.get(uuid).equals(false)) {
					if(e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
						soul.put(uuid, true);
						player.sendTitle(color(Config.soulStoneEquip()), color(Config.soulStoneEquipSubtitle()), 0, 40, 20);
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1F, 1F);
						particleCould(100, player.getLocation().add(0,1,0),Color.fromRGB(227, 151, 0), 0.5, 1 , 0.5);
						allStoneCheck(player);
						item.setAmount(item.getAmount() -1);
					}
				} else {
					player.sendMessage(color(Config.prefix() + Config.alreadyEquipped()));
					}		
				}
			}
		}
	}
	
	@EventHandler
	public void onClick(InventoryClickEvent e) {
		Player player = (Player) e.getWhoClicked();
		stoneClick(player, e,Config.mindStoneItem(), Config.mindStoneName(),  "Mind", (HashMap<String, Boolean>) mind);
		stoneClick(player, e, Config.soulStoneItem(), Config.soulStoneName(),  "Soul", (HashMap<String, Boolean>) soul);
		stoneClick(player, e, Config.spaceStoneItem(), Config.spaceStoneName(),  "Space", (HashMap<String, Boolean>) space);
		stoneClick(player, e, Config.powerStoneItem(), Config.powerStoneName(),  "Power", (HashMap<String, Boolean>) power);
		stoneClick(player, e, Config.timeStoneItem(), Config.timeStoneName(),  "Time", (HashMap<String, Boolean>) time);
		stoneClick(player, e, Config.realityStoneItem(), Config.realityStoneName(), "Reality", (HashMap<String, Boolean>) reality);
		
		
	}
	
	@EventHandler
	public void onDeath(PlayerDeathEvent e) {
		Player player = e.getEntity();
		if(Config.deleteStonesOnDeath()) {
		power.put(player.getUniqueId().toString(), false);
		time.put(player.getUniqueId().toString(), false);
		space.put(player.getUniqueId().toString(), false);
		mind.put(player.getUniqueId().toString(), false);
		soul.put(player.getUniqueId().toString(), false);
		reality.put(player.getUniqueId().toString(), false);
		return;
		}
		
		if(Config.dropStonesOnDeath()) {
			
		if(power.get(player.getUniqueId().toString())) {e.getDrops().add(new ItemBuilder(Config.powerStoneItem()).name(Config.powerStoneName()).addGlow().build());}
		if(mind.get(player.getUniqueId().toString())) {e.getDrops().add(new ItemBuilder(Config.mindStoneItem()).name(Config.mindStoneName()).addGlow().build());}
		if(time.get(player.getUniqueId().toString())) {e.getDrops().add(new ItemBuilder(Config.timeStoneItem()).name(Config.timeStoneName()).addGlow().build());}
		if(space.get(player.getUniqueId().toString())) {e.getDrops().add(new ItemBuilder(Config.spaceStoneItem()).name(Config.spaceStoneName()).addGlow().build());}
		if(reality.get(player.getUniqueId().toString())) {e.getDrops().add(new ItemBuilder(Config.realityStoneItem()).name(Config.realityStoneName()).addGlow().build());}
		if(soul.get(player.getUniqueId().toString())) {e.getDrops().add(new ItemBuilder(Config.soulStoneItem()).name(Config.soulStoneName()).addGlow().build());}
			
			power.put(player.getUniqueId().toString(), false);
			time.put(player.getUniqueId().toString(), false);
			space.put(player.getUniqueId().toString(), false);
			mind.put(player.getUniqueId().toString(), false);
			soul.put(player.getUniqueId().toString(), false);
			reality.put(player.getUniqueId().toString(), false);
			
		
		
		}
		
	}
	
	public void stoneClick(Player player, Event e, ItemStack stoneMaterial, String stoneName, String stonetype,  HashMap<String, Boolean> map) {
		if(((InventoryEvent) e).getView().getTitle().equals(ChatColor.translateAlternateColorCodes('&', ChatColor.translateAlternateColorCodes('&', Config.guiName().replace("%player-plural%", player.getName() + "'s").replace("%player%", player.getName()))))) {
			((InventoryInteractEvent) e).setCancelled(true);
			if(((InventoryClickEvent) e).getCurrentItem() != null) {
				if(((InventoryClickEvent) e).getCurrentItem().hasItemMeta()) {
					if(((InventoryClickEvent) e).getCurrentItem().getType() != Material.BLACK_STAINED_GLASS_PANE) {
						if(((InventoryClickEvent) e).getCurrentItem().getItemMeta().getDisplayName().equals(stoneMaterial.getItemMeta().getDisplayName())) {
							if(((InventoryClickEvent) e).getCurrentItem().getType().equals(stoneMaterial.getType())) {
							if(((InventoryClickEvent) e).getClickedInventory() != player.getInventory()) {
							if(player.getInventory().firstEmpty() == -1) {
								player.getWorld().dropItem(player.getLocation(), new ItemBuilder(stoneMaterial).name(stoneName).addGlow().build());
							}else {
								player.getInventory().addItem(new ItemBuilder(stoneMaterial).name(stoneName).addGlow().build());
							}
							map.put(player.getUniqueId().toString(), false);
							new StonesGUI(player);
							if(stonetype.equals("Space")) {
								player.setAllowFlight(false);
								player.setFlying(false);
							}
							player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(color("&c&l-&r " + stoneName))); 
							player.getWorld().playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1F, 1F);
							} else {
								//in player inventory
								if(((InventoryClickEvent) e).getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', stoneName))) {

									if(map.get(player.getUniqueId().toString())) {
										player.sendMessage(color(Config.alreadyEquipped()));
									}else {
										map.put(player.getUniqueId().toString(), true);
										new StonesGUI(player);
										player.spigot().sendMessage(ChatMessageType.ACTION_BAR,  new TextComponent(color("&a&l+&r " +  stoneName)));
										player.getWorld().playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1F, 1F);
										((InventoryClickEvent) e).getCurrentItem().setAmount(((InventoryClickEvent) e).getCurrentItem().getAmount() - 1);
									}
									
								}
							}
						}
						}
						
						
						
					}
				}
			}
		
		}
	}
	
	public void allStoneCheck(Player player) {
		if(hasAllStones(player)) {
			player.sendTitle(color(Config.theEndIsNear()), color(Config.theEndIsNearSubtitle()),0, 80, 0);

		}
	}
	
	public String color(String s) {return ChatColor.translateAlternateColorCodes('&', s);}
	
	public void particleCould(int amount, Location loc, Color color, double width, double length, double height) {
		DustOptions dustOptions = new DustOptions(color, 1);
	      loc.getWorld().spawnParticle(Particle.REDSTONE, loc, amount , width, height, length, dustOptions);	}
	
}








































