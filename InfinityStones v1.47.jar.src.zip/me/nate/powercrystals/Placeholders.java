package me.nate.powercrystals;

import java.util.HashMap;

import org.bukkit.entity.Player;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;

/**
	* This class will automatically register as a placeholder expansion
	* when a jar including this class is added to the /plugins/placeholderapi/expansions/ folder
	*
	*/
	public class Placeholders extends PlaceholderExpansion {
				
	    /**
	     * This method should always return true unless we
	     * have a dependency we need to make sure is on the server
	     * for our placeholders to work!
	     * This expansion does not require a dependency so we will always return true
	     */
	    @Override
	    public boolean canRegister() {
	        return true;
	    }

	    /**
	     * The name of the person who created this expansion should go here
	     */
	    @Override
	    public String getAuthor() {
	        return "Natecb13";
	    }

	    /**
	     * The placeholder identifier should go here
	     * This is what tells PlaceholderAPI to call our onPlaceholderRequest method to obtain
	     * a value if a placeholder starts with our identifier.
	     * This must be unique and can not contain % or _
	     */
	    @Override
	    public String getIdentifier() {
	        return "infinitystones";
	    }

	    /**
	     * if an expansion requires another plugin as a dependency, the proper name of the dependency should
	     * go here. Set this to null if your placeholders do not require another plugin be installed on the server
	     * for them to work
	     */
	    @Override
	    public String getPlugin() {
	        return null;
	    }

	    /**
	     * This is the version of this expansion
	     */
	    @Override
	    public String getVersion() {
	        return InfinityStones.getInstance().getDescription().getVersion();
	    }

	    /**
	     * This is the method called when a placeholder with our identifier is found and needs a value
	     * We specify the value identifier in this method
	     */
	    @Override
	    public String onPlaceholderRequest(Player p, String identifier) {

	        // %example_placeholder1%
	        if (identifier.equals("gauntlet")) {
	        	String s = "";
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.soul)) {s = s + "&6⬤ ";} else {s = s + "&7⬤ ";}
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.reality)) {s = s + "&c⬤ ";} else {s = s + "&7⬤ ";}
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.space)) {s = s + "&9⬤ ";} else {s = s + "&7⬤ ";}
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.mind)) {s = s + "&e⬤ ";} else {s = s + "&7⬤ ";}
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.power)) {s = s + "&5⬤ ";} else {s = s + "&7⬤ ";}
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.time)) {s = s + "&a⬤ ";} else {s = s + "&7⬤ ";}
	        	return s;

	        	
	        }
	        if (identifier.equals("soul_icon")) {
	        	String s = "";
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.soul)) {s = s + "&6⬤ ";} else {s = s + "&7⬤ ";}
	        	return s;
	        }
	        if (identifier.equals("reality_icon")) {
	        	String s = "";
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.reality)) {s = s + "&c⬤ ";} else {s = s + "&7⬤ ";}
	        	return s;
	        }
	        if (identifier.equals("space_icon")) {
	        	String s = "";
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.space)) {s = s + "&9⬤ ";} else {s = s + "&7⬤ ";}
	        	return s;
	        }
	        if (identifier.equals("mind_icon")) {
	        	String s = "";
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.mind)) {s = s + "&e⬤ ";} else {s = s + "&7⬤ ";}
	        	return s;
	        }
	        if (identifier.equals("power_icon")) {
	        	String s = "";
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.power)) {s = s + "&5⬤ ";} else {s = s + "&7⬤ ";}
	        	return s;
	        }
	        if (identifier.equals("time_icon")) {
	        	String s = "";
	        	if(InfinityStones.hasStone(p, (HashMap<String, Boolean>) InfinityStones.time)) {s = s + "&a⬤ ";} else {s = s + "&7⬤ ";}
	        	return s;
	        }
	        
	        if(identifier.equals("teleport_cooldown")) {
		    	   if(TimeStone.cooldown.containsKey(p.getUniqueId())){
		    		   if(System.currentTimeMillis() < TimeStone.cooldown.get(p.getUniqueId())) {
		    			   int time = (int) ((TimeStone.cooldown.get(p.getUniqueId()) - System.currentTimeMillis()))/1000;
		    			   return String.valueOf(time);
		    		   }
		    	   }
		    		   return "0";
		    	   
		    	   
		       }

	        if(identifier.equals("beam_cooldown")) {
	        	 if(RealityStone.cooldown.containsKey(p.getUniqueId())){
		    		   if(System.currentTimeMillis() < RealityStone.cooldown.get(p.getUniqueId())) {
		    			   int time = (int) ((RealityStone.cooldown.get(p.getUniqueId()) - System.currentTimeMillis()))/1000;
		    			   return String.valueOf(time);
		    		   }
		    	   }
		    		   return "0";
	        	
	        }
	        

	       
	        return null;
	    }
	}
	
	 
	
	

